#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Criado em 14/03/2021 10:00

@author: Carlos R Rocha
"""

nomearq = input ("Nome do arquivo: ")

print (f"Abrindo o arquivo {nomearq} como texto")
print ('--------------------------------------')

arq = open(nomearq, 'r')

for linha in arq:
    print (linha.rstrip())
    
arq.close()