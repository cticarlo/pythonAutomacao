#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Criado em 14/03/2021 10:00

@author: Carlos R Rocha
"""
def ehZero(x, tolerancia=1e-6):
  """ Recebe um valor e uma tolerância (por padrão, 1x10^-6)
      Retorna True se o absoluto de x for menor que essa tolerância
      O que significa que dá para considerá-lo igual a zero
  """
  return abs(x) < tolerancia



class Eq2Grau(object):
  """ Representa uma equação de 2o grau
      e suas funcionalidades
  """

  def __init__(self, a, b, c):
      """ Inicializa a equação
          Todo objeto deve ser consistente
      """
      self.a2 = a # coeficientes da equação
      self.a1 = b
      self.a0 = c
      # raízes da equação. Se None, não foi calculada ainda
      self.x = None


  def tipoRaizes(self):
    """Retorna uma string descrevendo os tipos de raízes"""
    if self.x is None:
      self.raizes()
    if self.x[1] is None:
      return "Uma raiz apenas (eq. de primeiro grau)"
    
    if isinstance(self.x[0],float):
      #TODO comparação de igualdade tolerante
      if self.x[0] == self.x[1]:
        return "Duas raízes inteiras iguais"
      else:
        return "Duas raízes inteiras diferentes"
    else:
      return "Duas raízes complexas"


  def raizes(self):
    """Retorna as raízes"""
    if self.x is None:
      if ehZero(self.a2):
        self.x = (-self.a0/self.a1, None)
      else:
        delta = self.a1**2 - 4*self.a2*self.a0
        if ehZero(delta):
          t =  -self.a1/(2*self.a2)
          self.x = (t, t)
        else:        
          self.x = ((-self.a1 + delta**0.5) / (2*self.a2),
                    (-self.a1 - delta**0.5) / (2*self.a2))
    return self.x


  def redefinirCoeficientes(self, a, b, c):
    self.a2 = a
    self.a1 = b
    self.a0 = c
    self.x = None


  def obterCoeficientes(self):
    return (self.a2, self.a1, self.a0)


  def independente(self, dependente):
    return self.a2*dependente**2 + self.a1*dependente + self.a0
