#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Criado em 14/03/2021 10:00

@author: Carlos R Rocha
"""

from equacoesoo import Eq2Grau

# Criatividade em modo texto
def lerCoeficientes():
  """ Le os coeficientes da equação
      no terminal
  """
  print("Resolução de equações de 2o grau")
  print("--------------------------------\n") 
  print("Para a equação ax² + bx + c = 0, forneça:")
  a2 = float(input ("Coeficiente a: "))
  a1 = float(input ("Coeficiente b: "))
  a0 = float(input ("Coeficiente c: "))
  return (a2, a1, a0)


def apresentarResultados(r):  
  """ Apresenta as raízes da equação no terminal
      r: tupla com dois valores
  """
  if r[1] is None: #Equacao de 1º grau
    print ("\n\nA equação é de 1º grau.")
    print (f"Sua única raiz é igual a {r[0]}.")
  else:
    print ("A equação é de 2º grau.")
    if r[0] == r[1]:
      print (f"Ela tem 2 raizes reais iguais a {r[0]}")
    elif isinstance(r[0],float):
      print (f"Ela tem 2 raizes reais diferentes: {r[0]:.2f} e {r[1]:.2f}")
    else:
      print (f"Ela tem 2 raizes complexas: {r[0]:.2f} e {r[1]:.2f}")


if __name__ == "__main__":    
    
    a, b, c = lerCoeficientes()
    
    eq2g = Eq2Grau(a, b, c)
    
    apresentarResultados(eq2g.raizes())

    print (eq2g.tipoRaizes())