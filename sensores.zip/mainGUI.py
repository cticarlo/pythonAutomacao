#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Criado em 15/03/2021 11:30

@author: Carlos R Rocha
"""

from kivy.uix.boxlayout import BoxLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput
from kivy.uix.button import Button
from kivy.uix.popup import Popup
from kivy.app import App

from sensor import Sensor

class VerificaSensor(App):
  def build(self):
    self._sensor = Sensor()
    self._inputs = {}
    # Cria os campos do formulário
    self._inputs['valor'] = TextInput(input_filter='int', multiline=False)
    self._inputs['nivel'] = TextInput(readonly=True)

    # Cria o formulário
    form = GridLayout(cols=2, size_hint_y=2/4.0)
    form.add_widget(Label(text='Valor adquirido'))
    form.add_widget(self._inputs['valor'])
    form.add_widget(Label(text='Nível'))
    form.add_widget(self._inputs['nivel'])

    # Cria os botões
    self._inputs['converter'] = Button(text='Converter', size_hint_y=1/4.0)
    self._inputs['calibrar'] = Button(text='Calibrar', size_hint_y=1/4.0)# Cria a tela principal
    tela = BoxLayout(orientation='vertical')
    tela.add_widget(form)
    tela.add_widget(self._inputs['converter'])
    tela.add_widget(self._inputs['calibrar'])

    # Adiciona os comportamentos
    self._inputs['converter'].bind (on_press=self.atualizarNivel)

    self._inputs['calibrar'].bind (on_press=self.executarCalibracao)

    return tela


  def atualizarNivel(self, *args):
    valor = int(self._inputs['valor'].text)
    nivel = self._sensor.converter(valor)
    self._inputs['nivel'].text = f"{nivel:2f}"


  def executarCalibracao(self, *args):
    self._sensor.calibrar('sensorNivel.csv')
    print(self._sensor._conv) # É errado fazer isso
    popup = Popup(title='Aviso',
            content=Label(text='Sensor calibrado'),
            size_hint=(0.8, 0.5))
    popup.open()



if __name__ == '__main__':
    VerificaSensor().run()
