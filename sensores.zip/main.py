#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Criado em 15/03/2021 10:00

@author: Carlos R Rocha
"""

from sensor import Sensor

sensorNivel = Sensor()
print ('Antes da calibração')
print ('-------------------')
print (f'840 corresponde a {sensorNivel.converter(840)}')

sensorNivel.calibrar('sensorNivel.csv')

print ('\n\nDepois da calibração')
print ('-------------------')
print (f'840 corresponde a {sensorNivel.converter(840)}')
