#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Criado em 15/03/2021 10:00

@author: Carlos R Rocha
"""
from numpy import genfromtxt, polyfit, poly1d

class Sensor(object):
  """ Define o comportamento de um sensor para o app
  """

  def __init__(self, arqConfig=None):
    """ Inicializa o sensor, carregando a sua
        configuração do arquivo arqConfig(se definido),
        senão assume que ele é linear, e a grandeza é
        de tensões entre 0 e 1V (como no ESP32), para
        um inteiro de 10 bits
    """
    if arqConfig is None:
      self.converter = self._linear1V
      self._valor = 0.0  # Último valor lido do sensor
      self._conv = None
    else:
      print ("Ainda por fazer")
  

  def _salvarConfig(self, arqConfig):
    """ Salva a configuração no arquivo cujo nome foi passado como parâmetro
    """
    pass
    #TODO Implementar no futuro


  def _linear1V(self, valor):
    """ Função de relação linear entre um inteiro de
        10 bits e níveis de tensão entre 0V e 1V
    """
    return valor*1.0 / 1024
  

  def _polinomial (self, valor):
    """ Utiliza uma função polinomial de 5a ordem
        para a conversão entre o valor passado e a grandeza medida
    """
    return self._conv(valor) if self._conv is not None else None


  def calibrar(self, arquivoCSV):
    """ Determina a curva de calibração do sensor a
        partir dos dados do arquivoCSV, onde cada linha
        corresponde a um par (grandeza, inteiro)
        Assume um polinômio de 5a ordem
    """
    ensaio = genfromtxt(arquivoCSV, delimiter=";")
    coeficientes = polyfit(ensaio[:,1], ensaio[:,0], 5)
    self._conv = poly1d(coeficientes)
    self.converter = self._polinomial

  def ler(self):
    """ Faz uma aquisição de dados de um sensor
        Existem várias formas disso acontecer
        Foge ao escopo do exemplo
    """
    pass
    #TODO Implementar de acordo com a plataforma