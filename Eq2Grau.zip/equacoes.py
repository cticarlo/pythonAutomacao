#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Criado em 13/03/2021 18:00

@author: Carlos R Rocha
"""
def ehZero(x, tolerancia=1e-6):
  """ Recebe um valor e uma tolerância (por padrão, 1x10^-6)
      Retorna True se o absoluto de x for menor que essa tolerância
      O que significa que dá para considerá-lo igual a zero
  """
  return abs(x) < tolerancia


def eq2Grau (a2, a1, a0, x):
  """Calcula o termo dependente da equação de 2o grau
     Pode ser utilizada por escalares ou arrays numpy
  """
  y = a2*x**2 + a1*x + a0
  return y


def calcularRaizes(a2, a1, a0):
  """Calcula as raízes de uma equação de 2o eq2Grau
     e retorna uma tupla com os dois resultados
     Se o segundo elemento da tupla for None, significa
     que a equação era de 1o grau (a2 = 0)
  """
  if ehZero(a2):
      return (-a0/a1, None)
  else:
      delta = a1**2 - 4*a2*a0
      if ehZero(delta):
          x = -a1/(2*a2)
          return (x, x)
      else:
          x1 = (-a1 + delta**0.5) / (2*a2)
          x2 = (-a1 - delta**0.5) / (2*a2)
          return (x1, x2)