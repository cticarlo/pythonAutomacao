#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Criado em 13/03/2021 18:00

@author: Carlos R Rocha
"""
import numpy as np
import matplotlib.pyplot as plt

from equacoes import eq2Grau, calcularRaizes

def apresentarResultados (x1, x2):
  if x2 is None: #Equacao de 1º grau
      print ("\n\nA equação é de 1º grau.")
      print (f"Sua única raiz é igual a {x1}.")
  else:
      print ("A equação é de 2º grau.")
      if x1 == x2:
          print (f"Ela tem 2 raizes reais iguais a {x1:2f}")
      elif isinstance(x1,float):
          print (f"Ela tem 2 raizes reais diferentes: {x1:.2f} e {x2:.2f}")
      else:
          print (f"Ela tem 2 raizes complexas: {x1:.2f} e {x2:.2f}")


def lerCoeficientes():
  print("Resolução de equações de 2o grau")
  print("--------------------------------\n") 
  print("Para a equação ax² + bx + c = 0, forneça:")
  huguinho = float(input ("Coeficiente a: "))
  zezinho  = float(input ("Coeficiente b: "))
  luisinho = float(input ("Coeficiente c: "))
  return (huguinho, zezinho, luisinho)


if __name__ == "__main__":
  a, b, c = lerCoeficientes()
  x1, x2  = calcularRaizes(a, b, c)
  apresentarResultados(x1, x2)
  
  x = np.linspace(-10,10, 101) # Cria um array de abcissas
  y = eq2Grau (a, b, c, x) # Obtém as ordenadas

  fig = plt.figure()
  plt.grid()                      # Cria grade
  plt.axhline(0,color='darkgray') # Cria eixo horizontal
  plt.axvline(0,color='darkgray') # Cria eixo vertical

  plt.plot (x, y, 'b')   # Traça a equação
  plt.show()